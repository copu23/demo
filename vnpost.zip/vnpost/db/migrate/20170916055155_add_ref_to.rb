class AddRefTo < ActiveRecord::Migration[5.0]
  def change
  	  # add_reference :hanghoas, :comment, foreign_key: true

  	  # remove_reference :comments, :vandon, index: true, foreign_key: true
  end
end
