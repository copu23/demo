class AddTableToRole < ActiveRecord::Migration[5.0]
  def change
    # add_reference :roles, :table, foreign_key: true
     # remove_reference :roles, :loaihang, index: true, foreign_key: true
	
  end
end
