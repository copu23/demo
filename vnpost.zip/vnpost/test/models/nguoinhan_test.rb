require 'test_helper'

class NguoinhanTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
