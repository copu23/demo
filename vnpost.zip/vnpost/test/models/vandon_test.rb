require 'test_helper'

class VandonTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
