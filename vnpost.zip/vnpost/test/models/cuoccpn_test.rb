require 'test_helper'

class CuoccpnTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
