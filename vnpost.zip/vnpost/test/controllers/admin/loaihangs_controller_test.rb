require 'test_helper'

class Admin::LoaihangsControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
