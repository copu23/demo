require 'test_helper'

class Nhanvien::HanghoasControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
