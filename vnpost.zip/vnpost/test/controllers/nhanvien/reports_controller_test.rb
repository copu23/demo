require 'test_helper'

class Nhanvien::ReportsControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
