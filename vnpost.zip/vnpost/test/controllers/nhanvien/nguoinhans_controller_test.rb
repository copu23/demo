require 'test_helper'

class Nhanvien::NguoinhansControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
