class Admin::HanghoasController < ApplicationController
end
