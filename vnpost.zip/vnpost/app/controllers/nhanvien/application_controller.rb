class Nhanvien::ApplicationController < ApplicationController
  layout "nhanvien"
  def index
  end
end
