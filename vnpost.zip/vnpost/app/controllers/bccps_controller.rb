class BccpsController < ApplicationController
	def idex
		
		
	end
end
