class Dichvucongthem < ApplicationRecord
	has_many :hanghoas

end
