class Mucphithuho < ApplicationRecord
end
