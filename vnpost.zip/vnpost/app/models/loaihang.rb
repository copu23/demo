class Loaihang < ApplicationRecord
	validates :tenlh, presence: true
	
end
