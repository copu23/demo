class Vung < ApplicationRecord
	has_many :tinhs
end
