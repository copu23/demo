class Nackhoiluong < ApplicationRecord
end
