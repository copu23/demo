module Admin::HanghoasHelper
end
